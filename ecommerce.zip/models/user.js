// const { all } = require("../app");
const bcrypt = require('bcrypt');

// module.exports = (sequelize, Sequelize) => {
//     const users = sequelize.define("users", {
//         id: {
//             type: Sequelize.INTEGER,
//             primaryKey: true,
//             autoIncrement: true
//         },
//         email: {
//             type: Sequelize.STRING,
//             allowNull: false,
//             unique: true
//         },
//         password: {
//             type: Sequelize.BLOB,
//             set(value) {
//                 let salt = crypto.randomBytes(16);
//                 this.setDataValue('salt', salt);
//                 this.setDataValue('password', crypto.pbkdf2Sync(value, salt, 310000, 32, 'sha256'));
//             }
//         },
//         salt: {
//             type: Sequelize.BLOB
//         },
//         name: {
//             type: Sequelize.STRING
//         },
//         emailVerified: {
//             type: Sequelize.BOOLEAN
//         },
//         image: {
//             type: Sequelize.STRING
//         },
//     }, {
//         timestamps: true
//     });

//     // users.associate = function (models) {
//     //     users.hasMany(models.orders, {
//     //         foreignKey: 'userId',
//     //         as: 'orders'
//     //     });
//     // };

//     return users;
// };


const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
    class User extends Model {
        static associate(models) {
            User.hasMany(models.Review, {
                foreignKey: "user_id",
            });
        }
    }
    User.init({
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        email: {
            type: DataTypes.TEXT,
            allowNull: false,
            unique: true
        },
        password: {
            type: DataTypes.TEXT,
            allowNull: false,
            set(value) {
                let salt = bcrypt.genSaltSync(10);
                this.setDataValue('password', bcrypt.hashSync(value, salt));
            }
        },
        name: {
            type: DataTypes.TEXT
        },
    }, {
        sequelize,
        timestamps: true
    });
    return User;
}
